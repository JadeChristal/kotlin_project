rootProject.name = "stags2022"
