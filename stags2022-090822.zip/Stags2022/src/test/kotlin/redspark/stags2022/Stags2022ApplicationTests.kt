package redspark.stags2022

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class Stags2022ApplicationTests {

	@Test
	fun contextLoads() {
	}

}
