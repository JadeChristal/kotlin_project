CREATE TABLE user_tab(
    id int auto_implement primary key,
    name varchar(255) not null,
    email varchar(255) not null,
    cpf varchar(255) not nul,
    date DateTime not null,
    status: varchar(255) not null
    );