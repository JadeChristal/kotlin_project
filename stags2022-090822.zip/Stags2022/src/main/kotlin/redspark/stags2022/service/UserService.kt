package redspark.stags2022.service

import org.springframework.data.domain.Page
import org.springframework.data.domain.Pageable
import org.springframework.stereotype.Service
import redspark.stags2022.enum.Errors
import redspark.stags2022.enum.UserStatus
import redspark.stags2022.exception.BadRequestException
import redspark.stags2022.exception.NotFoundException
import redspark.stags2022.model.UserModel
import redspark.stags2022.repository.UserRepository
import java.time.LocalDateTime

@Service
class UserService (val userRepository: UserRepository) {

    fun searchStatus(status: String, pageable: Pageable): Page<UserModel> {
        return if (status == "ATIVO") {
                    userRepository.findByStatusLike(UserStatus.ATIVO, pageable)
                } else {
                        if (status == "INATIVO") {
                            userRepository.findByStatusLike(UserStatus.INATIVO, pageable)
                        } else {
                                throw Exception()
                                }
                        }
    }

    fun maisVelho(): UserModel = userRepository.findFirstByOrderByDate()

    fun dezVelho(): List<UserModel> = userRepository.findFirst10ByOrderByDate()

    fun findId(id: Int): UserModel = userRepository.findById(id).orElseThrow{Exception(NotFoundException(Errors.ETG101.message.format(id), Errors.ETG101.code))}

    fun search(name: String?, pageable: Pageable): Page<UserModel> {
        name?.let {
            return userRepository.findByNameContaining(it, pageable)
        }
        return userRepository.findAll(pageable)
    }

    fun delete(id: Int) {
        if(!userRepository.existsById(id)) {
            throw BadRequestException(Errors.ETG201.message.format(id), Errors.ETG201.code)}
            userRepository.deleteById(id)
        }

    fun create(estag50: UserModel) {
        val dat = LocalDateTime.now()
        estag50.date = dat

        val validCPF = estag50.cpf
        val cpfClean = validCPF.replace(".", "").replace("-", "")
        if (cpfClean.isNotEmpty() && cpfClean.matches(Regex("\\d+"))) {
            when (cpfClean.length) {
                11 -> { }
                else -> {estag50.cpf = "CPF invállido"}
            }
        } else {estag50.cpf = "CPF inválido"}

        val verifica = "^\\w(.*)(@)(.*)(\\.com)(\\.br)?"
        val veremail = estag50.email
        val result = verifica.toRegex().matches(veremail)
            if (result) {
                estag50.email = veremail
            } else {
                estag50.email = "Email inválido"}

        estag50.status = UserStatus.ATIVO

        userRepository.save(estag50)
    }

    fun alter(estag50: UserModel) {
        if(!userRepository.existsById(estag50.id!!)) {throw Exception()}

        val data = estag50.date.toString()
        if (data.isBlank()) {
            val dat = LocalDateTime.now()
            estag50.date = dat}

        val verifica = "^\\w(.*)(@)(.*)(\\.com)(\\.br)?"
        val veremail = estag50.email
        val result = verifica.toRegex().matches(veremail)
        if (result) {estag50.email = veremail
        } else {estag50.email = "Email inválido"}


        if (estag50.password.isEmpty()) {
            estag50.password = "1234"}

        if (estag50.status != UserStatus.ATIVO){estag50.status = UserStatus.INATIVO}
        userRepository.save(estag50)
    }

    fun emailAvailable(email: String): Boolean = !userRepository.existsByEmail(email)

}