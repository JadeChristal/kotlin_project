package redspark.stags2022.model

import redspark.stags2022.enum.UserStatus
import java.time.LocalDateTime
import javax.persistence.*


@Entity
@Table(name = "user_tab")
open class UserModel(

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    open var id: Int? = null,

    @Column
    open var name: String,

    @Column
    open var email: String,

    @Column
    open var cpf: String,

    @Column
    open var date: LocalDateTime? = null,

    @Column
    @Enumerated(EnumType.STRING)
    open var status: UserStatus? = null,

    @Column
    open var password: String

)