package redspark.stags2022.exception

class BadRequestException(override val message: String, val errorCode: String): Exception() {
}