package redspark.stags2022.controller

import org.springframework.data.domain.Page
import org.springframework.data.domain.Pageable
import org.springframework.data.web.PageableDefault
import org.springframework.http.HttpStatus
import org.springframework.web.bind.annotation.*
import redspark.stags2022.controller.request.PostUserRequest
import redspark.stags2022.controller.request.PutUserRequest
import redspark.stags2022.controller.response.BossResponse
import redspark.stags2022.controller.response.DataResponse
import redspark.stags2022.controller.response.userResponse
import redspark.stags2022.extension.*
import redspark.stags2022.model.UserModel
import redspark.stags2022.service.UserService
import javax.validation.Valid


@RestController
@RequestMapping("/desafio3")

class UserController (
    val userService: UserService)
{
    @GetMapping
    fun search(@RequestParam name: String?, @PageableDefault(page = 0, size = 10) pageable: Pageable): Page<UserModel> = userService.search(name, pageable)

    @GetMapping("/status")
    fun searchStatus(@RequestParam status: String, @PageableDefault(page = 0, size = 5) pageable: Pageable): Page<userResponse> = userService.searchStatus(status, pageable).map { it.toUserResponse() }

    @GetMapping("/maisvelho")
    fun maisVelho(): DataResponse = userService.maisVelho().toDataResponse()

    @GetMapping("/10maisvelho")
    fun dezVelho(): List<DataResponse> = userService.dezVelho().map { it.toDataResponse() }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    fun create(@RequestBody @Valid estag50: PostUserRequest) = userService.create(estag50.toUserModel())

    @GetMapping("{id}")
    fun searchId(@PathVariable id: Int): BossResponse = userService.findId(id).toBossResponse()

    @PutMapping("{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    fun alter(@PathVariable id: Int, @RequestBody @Valid estag50: PutUserRequest) {
        val userSaved = userService.findId(id)
        userService.alter(estag50.toUserModel(userSaved))
    }

    @DeleteMapping("{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    fun delete(@PathVariable id: Int) = userService.delete(id)
 }
