package redspark.stags2022.controller.response

class FieldErrorResponse (
    var message: String,
    var field: String
        )
