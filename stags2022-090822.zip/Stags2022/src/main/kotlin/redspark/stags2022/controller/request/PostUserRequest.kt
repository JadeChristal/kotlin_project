package redspark.stags2022.controller.request

import org.hibernate.validator.constraints.br.CPF
import redspark.stags2022.validation.EmailAvailable
import javax.validation.constraints.Email
import javax.validation.constraints.NotEmpty

data class PostUserRequest (

    @field:NotEmpty(message = "Nome deve ser informado!")
    val name: String,

    @field:Email(message = "E-mail deve ser válido")
    @EmailAvailable
    val email: String,

    @field:CPF(message = "CPF deve ser válido")
    val cpf: String,

    @field:NotEmpty(message = "Deve ser digitada uma senha.")
    val password: String
    )