package redspark.stags2022.controller.request

import org.hibernate.validator.constraints.br.CPF
import org.springframework.format.annotation.DateTimeFormat
import redspark.stags2022.enum.UserStatus
import redspark.stags2022.validation.EmailAvailable
import java.time.LocalDateTime
import javax.validation.constraints.Email
import javax.validation.constraints.NotEmpty

data class PutUserRequest (

        @field:NotEmpty(message = "Nome deve ser informado!")
        val name: String,

        @field:Email(message = "E-mail deve ser válido")
        @EmailAvailable(message = "E-mail já está sendo usado")
        val email: String,

        @field:CPF(message = "CPF deve ser válido")
        val cpf: String,

        val date: LocalDateTime,

        val status: UserStatus
        )