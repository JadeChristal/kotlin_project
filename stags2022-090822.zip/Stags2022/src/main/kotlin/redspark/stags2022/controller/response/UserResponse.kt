package redspark.stags2022.controller.response

import redspark.stags2022.enum.UserStatus
import java.time.LocalDateTime

data class userResponse(
        var name: String,
        var email: String,
//        var date: LocalDateTime? = null,
        var status: UserStatus? = null
        )

data class DataResponse (
        var name: String,
        var date: LocalDateTime? = null,
        var status: UserStatus? = null
)

data class BossResponse(
        var id: Int? = null,
        var name: String,
        var email: String,
        var cpf: String,
        var date: LocalDateTime? = null,
        var status: UserStatus? = null,
        var password: String
        )