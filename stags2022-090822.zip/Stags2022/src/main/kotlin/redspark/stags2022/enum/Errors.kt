package redspark.stags2022.enum

enum class Errors(val code: String, val message: String) {

    ETG101("ETG-101", "Usuário [%s] não existe"),
    ETG201("ETG-201", "Usuário [%s] não cadastrado"),
    ETG301("ETG-301", "Valor inserido não é válido")

}