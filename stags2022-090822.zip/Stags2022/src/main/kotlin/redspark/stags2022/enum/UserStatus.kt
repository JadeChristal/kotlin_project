package redspark.stags2022.enum

enum class UserStatus {
    ATIVO,
    INATIVO
}