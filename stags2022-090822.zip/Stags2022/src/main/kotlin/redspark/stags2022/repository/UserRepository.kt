package redspark.stags2022.repository

import org.springframework.data.domain.Page
import org.springframework.data.domain.Pageable
import org.springframework.data.jpa.repository.JpaRepository
import redspark.stags2022.controller.response.DataResponse
import redspark.stags2022.enum.UserStatus
import redspark.stags2022.model.UserModel

interface UserRepository: JpaRepository<UserModel, Int>
{
    fun findByNameContaining(name: String, pageable: Pageable): Page<UserModel>

    fun findByStatusLike(status: UserStatus, pageable: Pageable): Page<UserModel>

    fun findFirstByOrderByDate(): UserModel

    fun findFirst10ByOrderByDate(): List<UserModel>

    fun existsByEmail(email: String): Boolean

}