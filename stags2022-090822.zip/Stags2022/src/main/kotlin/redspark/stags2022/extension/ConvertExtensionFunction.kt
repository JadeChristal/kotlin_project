package redspark.stags2022.extension

import redspark.stags2022.controller.request.PostUserRequest
import redspark.stags2022.controller.request.PutUserRequest
import redspark.stags2022.controller.response.BossResponse
import redspark.stags2022.controller.response.DataResponse
import redspark.stags2022.controller.response.userResponse
import redspark.stags2022.model.UserModel

fun PostUserRequest.toUserModel(): UserModel {
    return UserModel(
        name = this.name,
        email = this.email,
        cpf = this.cpf,
        password = this.password
    )
}

fun PutUserRequest.toUserModel(previous: UserModel): UserModel {
    return UserModel(
        id = previous.id,
        name = this.name,
        email = this.email,
        cpf = this.cpf,
        date = this.date,
        status = this.status,
        password = previous.password
    )
}

fun UserModel.toUserResponse(): userResponse {
    return userResponse(
        name = this.name,
        email = this.email,
//        date = this.date,
        status = this.status,
    )
}

fun UserModel.toDataResponse(): DataResponse {
    return DataResponse(
        name = this.name,
        date = this.date,
        status = this.status,
    )
}

fun UserModel.toBossResponse(): BossResponse {
    return BossResponse(
        id = this.id,
        name = this.name,
        email = this.email,
        cpf = this.cpf,
        date = this.date,
        status = this.status,
        password = this.password
    )
}